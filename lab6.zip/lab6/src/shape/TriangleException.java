package shape;

public class TriangleException extends Exception {
    public TriangleException(String msg) {
        super(msg);
    }
}