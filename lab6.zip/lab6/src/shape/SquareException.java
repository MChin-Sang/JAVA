package shape;

public class SquareException extends Exception {
    public SquareException(String msg) {
        super(msg);
    }
}
