package shape;

@FunctionalInterface
public interface Area {
    double calculate();
}
