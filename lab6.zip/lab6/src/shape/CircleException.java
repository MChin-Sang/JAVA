package shape;

public class CircleException extends Exception {
    public CircleException(String msg) {
        super(msg);
    }
}