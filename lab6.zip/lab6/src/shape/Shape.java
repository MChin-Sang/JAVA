package shape;

public interface Shape {
    double perimeter();
    String getName();
}
