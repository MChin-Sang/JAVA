package shape;

public class RectangleException extends Exception {
    public RectangleException(String msg) {
        super(msg);
    }
}
