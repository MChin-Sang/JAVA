package shape;

public class ParallelogramException extends Exception{
    public ParallelogramException(String msg) {
        super(msg);
    }
}
